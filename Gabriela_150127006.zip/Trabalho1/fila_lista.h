#ifndef fila_lista_h
#define fila_lista_h

int cria_fila();
int enfileira(int x);
int desenfileira(int *x);
int redimensiona();
int filaCheia();
int filaVazia();
void imprimeFila();

#endif
