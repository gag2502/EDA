#ifndef fila_vetor_h
#define fila_vetor_h

int cria_fila();
int enfileira(int x);
int desenfileira(int *x);
int redimensiona();
void filaCheia();
void filaVazia();
void imprimeFila();

#endif
