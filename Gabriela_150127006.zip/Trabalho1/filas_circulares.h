#ifndef filas_circulares_h
#define filas_circulares_h

int cria_fila();
int enfileira(int x);
int desenfileira(int *x);
int redimensiona();
void filaCheia();
void filaVazia();
void imprimeFila();


#endif
